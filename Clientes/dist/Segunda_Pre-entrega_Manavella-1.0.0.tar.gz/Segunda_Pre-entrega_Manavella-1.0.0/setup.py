from setuptools import setup

setup(

    name = "Segunda_Pre-entrega_Manavella",
    version = "1.0.0" ,
    author = "Andres Manavella",

    packages = [".Pre_entregas"]
)